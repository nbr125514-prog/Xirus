# AimTrainer (treino offline)

Aplicativo independente de treino de mira para Windows x64. Ele mostra um alvo ficticio em movimento e contabiliza pontos, acertos e tiros.

## Controles
- Clique no alvo vermelho para pontuar.
- `R`: reiniciar a sessao.
- `F`: mostrar/ocultar o circulo de referencia (FOV visual).
- `Esc`: sair.

Este projeto nao le memoria de CS2, nao identifica jogadores e nao automatiza mira em jogos. E um simulador separado.

## Compilar
Requer CMake e Visual Studio Build Tools (C++). Execute:

```powershell
cmake -S . -B build
cmake --build build --config Release
```

O executavel sera `build/Release/AimTrainer.exe` no Windows com Visual Studio.
