#define NOMINMAX
#include <windows.h>
#include <windowsx.h>
#include <string>
#include <cmath>
#include <sstream>
#include <algorithm>

static const wchar_t* CLASS_NAME = L"AimTrainerWindow";
struct App {
    int score = 0;
    int shots = 0;
    int hits = 0;
    int targetX = 480, targetY = 280;
    int vx = 4, vy = 3;
    int targetRadius = 18;
    bool showFov = true;
    bool running = true;
    ULONGLONG start = 0;
} app;

void PlaceTarget(HWND hwnd) {
    RECT r; GetClientRect(hwnd, &r);
    int w = std::max(1, r.right - r.left), h = std::max(1, r.bottom - r.top);
    app.targetX = 80 + rand() % std::max(1, w - 160);
    app.targetY = 110 + rand() % std::max(1, h - 170);
    app.vx = (rand() % 5 + 2) * (rand() % 2 ? 1 : -1);
    app.vy = (rand() % 5 + 2) * (rand() % 2 ? 1 : -1);
}

void DrawTextLine(HDC dc, int x, int y, const std::wstring& s, COLORREF color, int size=18) {
    SetTextColor(dc, color);
    SetBkMode(dc, TRANSPARENT);
    HFONT f = CreateFontW(size, 0, 0, 0, FW_SEMIBOLD, FALSE, FALSE, FALSE,
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
        DEFAULT_PITCH | FF_DONTCARE, L"Segoe UI");
    HFONT old = (HFONT)SelectObject(dc, f);
    TextOutW(dc, x, y, s.c_str(), (int)s.size());
    SelectObject(dc, old); DeleteObject(f);
}

void Paint(HWND hwnd) {
    PAINTSTRUCT ps; HDC dc = BeginPaint(hwnd, &ps);
    RECT r; GetClientRect(hwnd, &r);
    HBRUSH bg = CreateSolidBrush(RGB(14, 16, 21));
    FillRect(dc, &r, bg); DeleteObject(bg);

    HBRUSH panel = CreateSolidBrush(RGB(25, 28, 35));
    RECT top{0,0,r.right,76}; FillRect(dc,&top,panel); DeleteObject(panel);
    DrawTextLine(dc, 24, 14, L"AIM TRAINER  /  TREINO OFFLINE", RGB(240,240,245), 23);

    ULONGLONG elapsed = app.start ? (GetTickCount64()-app.start)/1000 : 0;
    std::wstringstream stats;
    stats << L"PONTOS: " << app.score << L"     ACERTOS: " << app.hits
          << L"     TIROS: " << app.shots << L"     TEMPO: " << elapsed << L"s";
    DrawTextLine(dc, 26, 46, stats.str(), RGB(190,196,207), 15);
    DrawTextLine(dc, 24, 92, L"CLIQUE NO ALVO VERMELHO  |  R: REINICIAR  |  F: FOV  |  ESC: SAIR",
                 RGB(145,153,166), 14);

    if (app.showFov) {
        HPEN pen = CreatePen(PS_DOT, 1, RGB(75, 90, 110));
        HPEN old = (HPEN)SelectObject(dc, pen);
        HBRUSH oldB = (HBRUSH)SelectObject(dc, GetStockObject(HOLLOW_BRUSH));
        int cx = r.right/2, cy = (r.bottom+76)/2;
        Ellipse(dc, cx-145, cy-145, cx+145, cy+145);
        SelectObject(dc, oldB); SelectObject(dc, old); DeleteObject(pen);
    }

    HBRUSH outer = CreateSolidBrush(RGB(205, 45, 55));
    HBRUSH inner = CreateSolidBrush(RGB(245, 245, 245));
    HBRUSH core = CreateSolidBrush(RGB(205, 45, 55));
    HBRUSH oldB = (HBRUSH)SelectObject(dc, outer);
    Ellipse(dc, app.targetX-app.targetRadius, app.targetY-app.targetRadius,
            app.targetX+app.targetRadius, app.targetY+app.targetRadius);
    SelectObject(dc, inner);
    Ellipse(dc, app.targetX-9, app.targetY-9, app.targetX+9, app.targetY+9);
    SelectObject(dc, core);
    Ellipse(dc, app.targetX-3, app.targetY-3, app.targetX+3, app.targetY+3);
    SelectObject(dc, oldB);
    DeleteObject(outer); DeleteObject(inner); DeleteObject(core);

    DrawTextLine(dc, 24, r.bottom-30, L"Simulador independente: nao interage com CS2 nem com outros jogos.",
                 RGB(105,115,130), 13);
    EndPaint(hwnd, &ps);
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch(msg) {
    case WM_CREATE:
        srand((unsigned int)GetTickCount());
        app.start = GetTickCount64();
        PlaceTarget(hwnd);
        SetTimer(hwnd, 1, 16, nullptr);
        return 0;
    case WM_TIMER: {
        RECT r; GetClientRect(hwnd, &r);
        app.targetX += app.vx; app.targetY += app.vy;
        if (app.targetX < 35 || app.targetX > r.right-35) app.vx = -app.vx;
        if (app.targetY < 125 || app.targetY > r.bottom-45) app.vy = -app.vy;
        InvalidateRect(hwnd, nullptr, FALSE);
        return 0;
    }
    case WM_LBUTTONDOWN: {
        int x = GET_X_LPARAM(lp), y = GET_Y_LPARAM(lp);
        app.shots++;
        int dx=x-app.targetX, dy=y-app.targetY;
        if (dx*dx+dy*dy <= app.targetRadius*app.targetRadius) {
            app.hits++; app.score += 100; PlaceTarget(hwnd);
        }
        InvalidateRect(hwnd,nullptr,FALSE);
        return 0;
    }
    case WM_KEYDOWN:
        if (wp == VK_ESCAPE) DestroyWindow(hwnd);
        if (wp == 'F') { app.showFov = !app.showFov; InvalidateRect(hwnd,nullptr,FALSE); }
        if (wp == 'R') {
            app.score=app.shots=app.hits=0; app.start=GetTickCount64();
            PlaceTarget(hwnd); InvalidateRect(hwnd,nullptr,FALSE);
        }
        return 0;
    case WM_PAINT: Paint(hwnd); return 0;
    case WM_DESTROY: KillTimer(hwnd,1); PostQuitMessage(0); return 0;
    }
    return DefWindowProcW(hwnd,msg,wp,lp);
}

int WINAPI wWinMain(HINSTANCE instance, HINSTANCE, PWSTR, int show) {
    WNDCLASSW wc{};
    wc.lpfnWndProc = WndProc;
    wc.hInstance = instance;
    wc.lpszClassName = CLASS_NAME;
    wc.hCursor = LoadCursor(nullptr, IDC_CROSS);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
    RegisterClassW(&wc);

    HWND hwnd = CreateWindowExW(0, CLASS_NAME, L"Aim Trainer - Offline Practice",
        WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, 900, 620,
        nullptr, nullptr, instance, nullptr);
    if (!hwnd) return 1;
    ShowWindow(hwnd, show);
    UpdateWindow(hwnd);
    MSG msg{};
    while (GetMessageW(&msg,nullptr,0,0) > 0) {
        TranslateMessage(&msg); DispatchMessageW(&msg);
    }
    return (int)msg.wParam;
}
