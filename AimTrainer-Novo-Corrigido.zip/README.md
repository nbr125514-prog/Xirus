# AimTrainer - treino offline

Treinador independente para Windows. Clique no alvo vermelho em movimento para pontuar.

Controles:
- Clique no alvo: marcar acerto
- R: reiniciar
- F: mostrar/ocultar circulo de referencia
- Esc: sair

Nao interage com CS2, nao le memoria de jogos e nao automatiza mira em partidas.

Compilacao local: `cmake -S . -B build` e `cmake --build build --config Release`.
